# install
## linux
```
apt-get install libyaml-cpp-dev libgoogle-glog-dev libopencv-dev libgflags-dev
```
```
mkdir build
cd build
cmake ..
make -j4
```

