#pragma once

extern "C"
{
    void* Init(char *TargetFrameBufferFile);
    void Display(void* FrameBufferHandle, unsigned char* Image, int Width, int Height);
    int GetFrameBufferX_Resolution(void* FrameBufferHandle);
    int GetFrameBufferY_Resolution(void* FrameBufferHandle);
    void DeInit(void* FrameBufferHandle);
}
