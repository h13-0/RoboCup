import threading
import time
from enum import Enum

import numpy as np
import cv2 as cv

from FrameBufferMonitor.FrameBufferMonitor import FrameBufferMonitor
from YoloDetector.YoloDetector import LoadYoloV4_Tiny
from Protocol.SerialProtocol import SerialProtocol, ProtocolVariablesType


class WorkingMode(Enum):
    '''
        @brief: Define working mode enumeration.
    '''
    StandBy = 0
    AppleDetectMax = 1
    AppleDetectLeft = 2
    AppleDetectRight = 3
    TargetDetection = 4
    FruitIdentify = 5


class MainWorkingFlow():
    def __init__(self, 
        CameraID, SerialPort : str, BaudRate : int,
        RKNN_WeightPath : str = "./YoloDetector/yolov4-tiny.rknn",
        RKNN_Lables : list = ["Apple","Banana", "KiwiFruit", "Lemon", "Orange", "Peach", "Pear", "Pitaya", "SnowPear"],
        RKNN_Width : int = 320, RKNN_Height : int = 224,
        DisplayFPS : bool = True, DisplayWorkingMode : bool = True
    ) -> None:
        '''
            @brief: Initialize MainWorkingFlow.
            @param: 
                SerialPort: Serial port.
                BaudRate: Baud rate.
        '''
        # Set camera variables.
        self.__cameraID__ = CameraID
        self.__frame__ = None
        self.__frameLock__ = None
        self.__refreshFrameThread__ = None

        # Set FrameBufferMonitor variables.
        self.__frameBufferMonitor__ = None

        # Set yolo variables.
        self.__rknnWeightPath__ = RKNN_WeightPath
        self.__rknnLables = RKNN_Lables
        self.__rknnWidth__ = RKNN_Width
        self.__rknnHeight__ = RKNN_Height
        self.__yoloDetector__ = None
        
        # Set target variables.
        self.__targetDetector__ = None

        # Set protocol.
        self.__serialPort__ = SerialPort
        self.__baudRate__ = BaudRate
        self.__protocol__ = None

        # Set working mode variables.
        self.__workingMode__ = WorkingMode.StandBy
        self.__workingModeLock__ = threading.Lock()

        # Set additional variables.
        self.__displayFPS = DisplayFPS
        self.__displayWorkingMode = DisplayWorkingMode

        # Set main method variables.
        self.__mainMethodThread__ = None

        # Set exit flag.
        self.__exitFlag__ = False
        self.__exitFlagLock__ = threading.Lock()


    def __cmdCallback__(self, Mode : str) -> None:
        '''
            @brief: Switch mode command callback function.
            @param: Mode: Switch mode.
        '''
        with self.__workingModeLock__:
            if(Mode == "AppleDetectMax"):
                self.__workingMode__ = WorkingMode.AppleDetectMax
                print("Switch to mode: " + Mode)
            elif(Mode == "AppleDetectLeft"):
                self.__workingMode__ = WorkingMode.AppleDetectLeft
                print("Switch to mode: " + Mode)
            elif(Mode == "AppleDetectRight"):
                self.__workingMode__ = WorkingMode.AppleDetectRight
                print("Switch to mode: " + Mode)
            elif(Mode == "TargetDetection"):
                self.__workingMode__ = WorkingMode.TargetDetection
                print("Switch to mode: " + Mode)
            elif(Mode == "FruitIdentify"):
                self.__workingMode__ = WorkingMode.FruitIdentify
                print("Switch to mode: " + Mode)
            else:
                pass


    def __standBy__(self, Frame : np.ndarray):
        pass


    def __drawYoloResult__(self, Frame : np.ndarray):
        pass

    def __appleDetectMax__(self, Frame : np.ndarray):
        pass


    def __refreshFrame__(self):
        '''
            @brief: Refresh frame method when camera source is video stream.
        '''
        while(True):
            # Get frame from camera.
            ret, frame = self.__camera__.read()
            if(ret):
                with self.__frameLock__:
                    self.__frame__ = frame.copy()

            # exit method.
            exitFlag = False
            with self.__exitFlagLock__:
                exitFlag = self.__exitFlag__
            if(exitFlag):
                break

            time.sleep(0.02)


    def __mainMethod__(self) -> None:
        '''
            @brief: Main working method.
        '''
        # Initialize FrameBufferMonitor.
        self.__frameBufferMonitor__ = FrameBufferMonitor("/dev/fb0")
        FrameBufferMonitor.Display(cv.imread("./Logo.jpg"))


        # Initialize camera.
        self.__camera__ = cv.VideoCapture(self.__cameraID__)
        if(type(self.__cameraID__) is str):
            self.__frameLock__ = threading.Lock()
            self.__refreshFrameThread__ = threading.Thread(target = self.__refreshFrame__)
            self.__refreshFrameThread__.start()


        # Initialize YoloDetector. 
        while(self.__yoloDetector__ is None):
            try:
                self.__yoloDetector__ = LoadYoloV4_Tiny(
                    self.__rknnWeightPath__, self.__rknnLables, self.__rknnWidth__, self.__rknnHeight__
                )
            except:
                print("RKNN loading failed.")


        # Initialize targetDetector.

    
        # Initialize protocol.
        self.__protocol__ = SerialProtocol(self.__serialPort__, self.__baudRate__)
        ## Add callback function.
        self.__protocol__.AddCallback("CMD", ProtocolVariablesType.string, self.__cmdCallback__)

        # Enter the main cycle.
        while(True):
            # Get frame from camera.
            frame = None
            if(type(self.__cameraID__) is int):
               ret, frame = self.__camera__.read() 
            elif(type(self.__cameraID__) is str):
                with self.__frameLock__:
                    frame = self.__frame__.copy()
            else:
                break

            if(frame is not None):
                # Image processing.
                startTime = time.time()
                
                # Copy working mode.
                currentWorkingMode = None
                with self.__workingModeLock__:
                    currentWorkingMode = self.__workingMode__
                
                # Enter working mode.
                if(currentWorkingMode == WorkingMode.StandBy):
                    self.__standBy__(frame)
                elif(currentWorkingMode == WorkingMode.AppleDetectMax):
                    self.__appleDetectMax__(frame)

                endTime = time.time()

                # Calculate frame rate.
                if(self.__displayFPS):
                    fps = 1.0 / (endTime - startTime)
                    cv.putText(frame, "FPS: {:.2f}".format(fps), (0, 30), cv.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
                    pass
                
                # Display working mode.
                if(self.__displayWorkingMode):
                    pass

                # Display frame.

            else:
                print("Camera read failed.")
                time.sleep(0.1)

            # Synchronous working mode.
            '''
                Key = `WM`  
                Type = uint8_t  
                | Value | Mode             |
                | ----- | ---------------- |
                | 0     | Standby          |
                | 1     | AppleDetectMax   |
                | 2     | AppleDetectLeft  |
                | 3     | AppleDetectRight |
                | 4     | TargetDetection  |
                | 5     | FruitIdentify    |
            '''
            self.__protocol__.SendChar("WM", currentWorkingMode.value)

            exitFlag = False
            with self.__exitFlagLock__:
                exitFlag = self.__exitFlag__
            if(exitFlag):
                break


    def Run(self, Block : bool = True) -> None:
        """
        
        """
        if(Block):
            self.__mainMethod__()
        else:
            self.__mainMethodThread__ = threading.Thread(target = self.__mainMethod__)
            self.__mainMethodThread__.start()


    def __del__(self):
        # Set exit flag.
        with self.__exitFlagLock__:
            self.__exitFlag__ = True

        # Wait for threads to exit.
        if(self.__mainMethodThread__ is not None):
            self.__mainThread__.join()

        if(self.__refreshFrameThread__ is not None):
            self.__refreshFrameThread__.join()
